### Indicate successful recovery
###

Print "Finished '$WORKFLOW'. The target system is mounted at '$TARGET_FS_ROOT'."
