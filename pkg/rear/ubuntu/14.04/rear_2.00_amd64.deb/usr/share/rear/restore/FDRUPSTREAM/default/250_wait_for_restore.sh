#
# Pause for FDRUPSTREAM restore
#

echo "   Perform your restore using Director or Web Portal."
echo
echo "   IMPORTANT:  restore the entire '/' filesystem to '$TARGET_FS_ROOT'"
echo "   on the recovery system."
echo "   When the restore is complete, then hit <enter> here."
read
