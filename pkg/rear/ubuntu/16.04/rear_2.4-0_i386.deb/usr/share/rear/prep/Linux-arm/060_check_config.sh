if [ "$OUTPUT" != "PXE" ] ; then
    Error "Currently only OUTPUT=PXE is supported on ARM"
fi
